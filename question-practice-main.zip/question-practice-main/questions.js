
const question_1 =  {
    name: 'answer',
    message: '¿You ave added a new user to PureCloud but they dont have the phone call icon on the left pane, so they are unable to place calls. What is the most likely reason for this?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)The user deleted the icon ',
      'b)The user is not assigned the appropiate permissions/role',
      'c)The users phone is unplugged',
      'd)The user did not assign a phone number to themselves',
    ]
};
const question_2 =  {
    name: 'answer',
    message: '¿Several people have complaned that they try to join a group chat and they cant find the group in a search. What is the most likely reason?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)The group is in the wrong organitazion',
      'b)Group chat is only available to administrators',
      'c)The group is set to members only and they are not members of the group',
      'd)The group is set to public',
    ]
};


const question_3 =  {
      name: 'answer',
      message: '¿What two options are available to create a customized role?',
      correct:"a",
      limit: 10,
      initial: 2,
      choices: [
        'a)Copy an existing role then add the necessary permissions to meet your needs b)Create a new role and assign the necessary permissions to that role',
        'c)Create or modify a workgroup to meet your needs',
        'd)Create a new group and assign the necessary permissions to the group',
      ]
  };

const question_4 =  {
      name: 'answer',
      message: '¿What is the recommended way to create a .csv file?',
      correct:"b",
      limit: 10,
      initial: 2,
      choices: [
        'a)Use a text editor, such as, Notepad to create your .csv files',
        'b)Create a spreadsheet and export it as a .csv file',
        'c)Use a word processing application, such as Microsoft Word, to create your .csv files',
	'd)Use a .csv application to create .csv files',     
      ]
  };

const question_5 =  {
      name: 'answer',
      message: '¿What are the default roles for quality management that are enabled with the pureCloud Contact Center License? Choose 2 answers?',
      correct:"a",
      limit: 10,
      initial: 2,
      choices: [
        'a)Quality Administrator d)Quality Evaluator',
        'b)Quality Recorder',
        'c)Real-Time Supervisor',
	      
      ]
  };


const question_6 =  {
      name: 'answer',
      message: '¿What is the alerting timeout with regard to queue configuration?',
      correct:"d",
      limit: 10,
      initial: 2,
      choices: [
        'a)This is how long the interaction will alert before disconnecting',
        'b)This is how long the agent has to complete after call work',
        'c)This is how long the interaction will wait to begin alerting the agent',
	'd)This is how long the interaction will alert before timing out and setting the agents status to not responding',      
      ]
  };


const question_7 =  {
      name: 'answer',
      message: 'Select the categories of ACD skills which can be added to a user or intercation. Choose 2 answers',
      correct:"a",
      limit: 10,
      initial: 2,
      choices: [
        'a)Languaje c) Skills', 
        'b)Roles',
        'c)Skills',
        'd)Queue',
      ]
  };


const question_8 =  {
      name: 'answer',
      message: 'Which definition matches the after call work option mandatory, time-boxed?',
      correct:"b",
      limit: 10,
      initial: 2,
      choices: [
        'a)The agent may or may not complete after call work. The system will set them to available after an intercation completes. They are responsible for setting their availability appropiately if perfoming after call work',
        'b)The agent is automatically placed into an after call work status and the system will automatically set them to available when the after call timeout is reached. The agent may set themselves to available if they complete their after call work early',
        'c)The agent is automatically placed into an after call work status and the system will automatically set them to available when the after call timeout is reached. The agent may not set themselves to available if they complete their after call work early',
	'd)The agent is placed in an after call work status and must manually set their status back to available when their after cll work is complete',
      ]
  };

const question_9 =  {
      name: 'answer',
      message: 'Which definition matches the ACD evaluation method best available skills?',
      correct:"c",
      limit: 10,
      initial: 2,
      choices: [
        'a)Looks for the first acailable agent and ignores any skill requirements',
        'b)Matches the intercation to the first available agent who has all of the requested skills',
        'c)Evaluates the first 100 agents to find the agent with the highest average proficiency rating. The average is calculated using the agentes proficiency rating for each of the requested skills',
      ]
  };

const question_10 =  {
      name: 'answer',
      message: 'The utilization feature of purecloud allows administrators to configure. Choose 3 answers',
      correct:"a",
      limit: 10,
      initial: 2,
      choices: [
        'a)The maximun capacity that an agent may handle simultaneously for each support media type d)The number of different media types that an agent may handle simultaneously e) The media types that cn interrupt intercations that an agent in handing',
        'b)The after call work time for each media type',
        'c)The length of time that an agent may spend on each media type',
	'd)The number of different media types that an agent may handle simultaneously',
	'e)The media types that cn interrupt intercations that an agent in handing',
      ]
  };

const question_11=  {
    name: 'answer',
    message: 'Why are skills and languages configured separately?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)So that skills can have a more granular',
      'b)So that an agent with a skill can receive an intercation regardless of the language requirement',
      'c)So that an agent with a language capability can receive an intercation regardless of the skill requirement',
      'd)Skills are a subset of languages so that the two can be combined to determine if the agent will receive an interaction',
    ]
};

const question_12=  {
    name: 'answer',
    message: 'What additional functionality will your business have by setting up and using ACD messaging in your contact center?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)The ability to receive and route specific tweets to agentes so that they can respond to those tweets',
      'b)The ability to create and manage a facebook page',
      'c)The ability to have agents spontaneously post information about your business to twitter, facebook and other social media outlets',
      'd)The ability for customers to acces their accounts via social media channels',
    ]
};


const question_13=  {
    name: 'answer',
    message: 'The builseye routing method relaxes the required skills as the selection pool expands from one ring to the next. How many rings maximun may be defined for bulseye routing?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)8',
      'b)6',
      'c)4',
      'd)2',
    ]
};



const question_14=  {
    name: 'answer',
    message: 'What is the purpose of the wrap-up code mappings?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)The mappings allow you to associate some behavior with the wrap-up code, such as callback time.',
      'b)The mappings allow you to associate  wrap-up code to specific campaigns',
      'c)The mappings configures outbound dialing to flag a single number or the entire contact as uncallable, or the right party contacted based on the wrap-up code assigned to the interaction',
      'd)The mappings allow you to associate  wrap-up code to specific queues',
    ]
};



const question_15=  {
    name: 'answer',
    message: 'Which definition matches the ACD evaluation method all skils matching?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Looks for the first available agent and ignores any skill requirements',
      'b)Matches the intercation to the first available agent who has all of the requested skills',
      'c)Evaluates the first 100 agents to find the agent with the highest average proficiency rating. The average is calculated using the agentes proficiency rating for each of the requested skills',
    ]
};




const question_16=  {
    name: 'answer',
    message: 'A queue is configured for standard ACD routing and disregard skills, next agent for the evaluation method. What agent property is used to determine the next available agent?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Skill',
      'b)Time since they last handled an ACD interaction',
      'c)Cost',
      'd)Department',
    ]
};




const question_17=  {
    name: 'answer',
    message: 'Which routing uses interaction flows to analyze the customer needs and connects the customer to the appropiate resource',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Skill based routing',
      'b)Intercation routing',
      'c)ACD routing',
      'd)IVR routing',
    ]
};



const question_18 =  {
    name: 'answer',
    message: 'Wich of the following can be configured on inbound interactions to be used by ACD processing? Choose 2 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Language c)skills',
      'b)Intent of call',
      'c)Skills',
      'd)Agent Availability',
    ]
};



const question_19=  {
    name: 'answer',
    message: 'PureCloud ACD assigns interactions to the most appropriate available agent. What attributes can be used to determine the best available agent? Choose 3 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Skills c)Language d)Time since the agent became available',
	  'e)Staffing requirements',
    ]
};



const question_20=  {
    name: 'answer',
    message: 'What do the default service level and srvice level target for voice interactions mean?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)80 calls and chats must be answered every 20 seconds',
      'b)80% of calls and chat must be answered within 20 seconds',
      'c)80% of agents must answer calls and chat within 20 seconds',
      'd)20 chats and calls must be answered in 80 seconds',
    ]
};



const question_21=  {
    name: 'answer',
    message: 'Wich ACD option helps PureCloud to apply business rules in order to process an interaction?',
    correct:"d",
    limit: 10,
    initial: 2,
    choices: [
      'a)Routing method',
      'b)Call flow',
      'c)Evaluation method',
      'd)ACD Processing',
    ]
};


const question_22=  {
    name: 'answer',
    message: 'Your contact center wants to track the outcome of calls and chats. What can be configured withing PureCloud to provide this functionality',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Account codes',
      'b)Wrap-up codes',
      'c)Resolution codes',
      'd)Status',
    ]
};


const question_23=  {
    name: 'answer',
    message: 'Wich definition matches the after call work option mandatory, discretionary?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)The agent is automatically placed into an after call work status and the system will automatically set them to available when the after call timeout is reached. The agent may set themselves to available if they complete their after call work early',
      'b)The agent is placed in an after call work status and must manually set their status back to available when their after cll work is complete',
      'c)The agent is automatically placed into an after call work status and the system will automatically set them to available when the after call timeout is reached. The agent may not set themselves to available if they complete their after call work early',
      'd)The agent may or may not complete after call work. The system will set them to available after an intercation completes. They are responsible for setting their availability appropiately if perfoming after call work',
    ]
};


const question_24=  {
    name: 'answer',
    message: 'When enable calls is turned on for a group, purecloud routes interactions to all members either sequentially or randomly',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)True',
      'b)false',
    ]
};


const question_25=  {
    name: 'answer',
    message: 'Which of the following are ACD evaluation methods? Choose 3 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)All skills matching b)Best available skills d)Disregard skills',
      'c)Bullseye matching',
    ]
};


const question_26=  {
    name: 'answer',
    message: 'Which ACD routing method routes interaction to the next available agent?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Bullseye ACD',
      'b)Standard ACD',
      'c)Skills based routing',
      'd)All of the above',
    ]
};



const question_27=  {
    name: 'answer',
    message: 'A systems that routes interactions based on an algorithm which determines the best available agent for an interaction',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Architect',
      'b)Automatic call distribution',
      'c)Call routing',
      'd)Scheduling',
    ]
};



const question_28=  {
    name: 'answer',
    message: 'Which of the following reports are in the exports category',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Agent activity summary',
      'b)Interaction details report c)Agent activity summary export e)Agent metrics export report f)Queue metrics interval export',
      'c)Agent activity summary export',
      'd)Agent activity export report',
	  'e)Agent metrics export report',
    ]
};



const question_29=  {
    name: 'answer',
    message: 'Which of the following are components of purecloud reporting and analitycs. Choose 3 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Reports c)Dashboard d)Interaction',
      'b)Dynamics views',
    ]
};



const question_30=  {
    name: 'answer',
    message: 'Where can you access the contact center dashboard',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Performance > Overview',
      'b)Performance > Menú',
      'c)Performance > Agents',
    ]
};




const question_31=  {
    name: 'answer',
    message: 'Which of the performance views shows real-time data with historical metrics to give you both short term and long-term views?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Reports',
      'b)Dashboard',
      'c)Dynamics views',
      'd)All of the above',
    ]
};



const question_32=  {
    name: 'answer',
    message: 'Purecloud enables automatic license assignment by default',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)True',
      'b)False',
    ]
};



const question_33=  {
    name: 'answer',
    message: 'Neo Corporación plans to purchase the purecloud contact center solution from genesys to meet their requirement for unlimited multi chanel intercation routing. Which would be the right license level for them to purchase',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Purecloud 1',
      'b)Purecloud 2',
      'c)Purecloud 3',
      'd)Collaborate',
	  'e)Communicate',
    ]
};




const question_34=  {
    name: 'answer',
    message: 'Under which container is queue available',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Contact Center',
      'b)Telephony',
      'c)Integration',
      'd)Routing',
    ]
};



const question_35=  {
    name: 'answer',
    message: 'Which option allows the flow to be interrupted if the caller says something while in the IVR?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Add blank audio',
      'b)Enable speech recognition for the entire flow',
      'c)Menu prompt',
      'd)Menu option',
    ]
};




const question_36=  {
    name: 'answer',
    message: 'Which option in the audio sequence configuration allows you to add a slight amount of silence as a menu prompt to avoid architect',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Default menu choice',
      'b)Menu option',
      'c)Add blank audio',
      'd)Menu prompt',
    ]
};



const question_37=  {
    name: 'answer',
    message: 'How many types of flows are supported by architect?',
    correct:"d",
    limit: 10,
    initial: 2,
    choices: [
      'a)5',
      'b)6',
      'c)7',
      'd)8',
    ]
};



const question_38=  {
    name: 'answer',
    message: 'What purecloud feature can you use to present details about a caller to the agent and allow the agent to update or collect information?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Dialog boxes',
      'b)Scripts',
      'c)Toast pop-ups',
      'd)IVR prompts',
    ]
};




const question_39=  {
    name: 'answer',
    message: 'What is the purpose of scripts within purecloud contact center?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Scripts can be used for inbound intercations only',
      'b)Scripts can be used to guide you when setting up architect',
      'c)Scripts can be used for inbound intercations, manually dialed calls in additions to outbound dialing campaigns',
      'd)Scripts can be used for outbound dialing campaigns only',
    ]
};



const question_40=  {
    name: 'answer',
    message: 'The script editor allows you to create custom scripts and templates to use with purecloud. What are some of the options available withem the script editor? Choose 3 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)You can add scripter variables and actions, or create custom variables and actions to use within your scripts b)You can cut, copy and paste components of a script to other areas within the script d)You can add many controls, such as text boxed, drop down list, radio buttons and numeric fields to scripts that provide for agent input',
      'c)You can use any of the scripter variables and actions for your scripts but you may not create custom variables and actions',
	  'e)You can copy and paste component between scripts',
    ]
};


const question_41=  {
    name: 'answer',
    message: 'Scripts are presented to an agent via screen pop',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)True',
      'b)False',
    ]
};


const question_42=  {
    name: 'answer',
    message: 'For outbound dialing, where do you assign the script used by the campaign?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Admin > Outbound Dialing > Campaigns',
      'b)Admin > Outbound Dialing > Outbound Settings',
      'c)Admin > Outbound Dialing > Campaign Management',
    ]
};


const question_43=  {
    name: 'answer',
    message: 'Which dialing mode allows the agent to see customer information before dialing?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Progressive',
      'b)Predictive',
      'c)Preview',
      'd)Power',
    ]
};


const question_44=  {
    name: 'answer',
    message: 'What does it imply when a campaign does not dial a list of telephone number?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)They are in the DNC list',
      'b)The call went unanswered',
      'c)Unable to reach the customer',
      'd)The telephone number is wrong',
    ]
};



const question_45=  {
    name: 'answer',
    message: 'Which of the following settings are required when creating a campaign? Choose 3 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Contact list c)Agent script d)Queue',
      'b)DNC list',
    ]
};



const question_46=  {
    name: 'answer',
    message: 'What is the default call count dialed for the global configuration setting called max calls per agent?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)15',
      'b)12',
      'c)11',
      'd)no limit',
    ]
};



const question_47=  {
    name: 'answer',
    message: 'What statements are true regarding contact lists used for outound campaings? Choose 3 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Contact lists must contain the home phone number and first and last name fields at a minimun c,d and e',
      'b)Contact lists are read-only and cannot be updated by the agents',
      'c)A contact list can have its own unique structure, including an arbitrary number of phone number types',
      'd)Each campaign can have its own contact list or contact list can be shared arnong campaigns',
	  'e)To use the callable times feature, each phone number column must have a corresponding time zone column containing the zone name',
    ]
};



const question_48=  {
    name: 'answer',
    message: 'Where can you view agent evaluation scores, evaluation activity, and calibration activity in real time?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Reports',
      'b)Performance > Agents',
      'c)Admin > Contact Center',
      'd)Admin > Quality',
    ]
};



const question_49=  {
    name: 'answer',
    message: 'What process helps you to standardize call evaluations of contact center agents by companing multiple reviews of the same call or intercation?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Scoring',
      'b)Monitoring',
      'c)Calibration',
      'd)Evaluation',
    ]
};




const question_50=  {
    name: 'answer',
    message: 'Purecloud quality managment features provide several methods to create calibrations, and for selection recordings for calibration sessions. Which option automatically assigns calibrations to evaluators?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Create a policiy to assign recordings, based on certain interaction criteria for calibration',
      'b)Create a calibration by selecting a recordin from an intercation search',
      'c)Create a calibration by selecting a completed evaluation',
    ]
};



const question_51=  {
    name: 'answer',
    message: 'What browsers are supported for use with all purecloud features? Choose all that apply Choose 2 answers',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Internet Explores',
      'b)Firefox and Chrome',
      'c)Chrome',
      'd)Safari',
	  'e)Opera',
    ]
};



const question_52=  {
    name: 'answer',
    message: 'What are the categories of rules that can be defined for rule sets in outbound campaigns? Choose 2 answers',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Post call',
      'b)Pre call d)Wrap-up',
      'c)On call',
      'd)Wrap-up',
    ]
};



const question_53=  {
    name: 'answer',
    message: 'What would you select from the performance menu to view real time statistics for all active campaigns?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Scripts',
      'b)Campaign managment',
      'c)Outbound campaigns',
      'd)Schedules',
    ]
};



const question_54=  {
    name: 'answer',
    message: 'Wich option provides the ability for an email interaction to be interrupted by voice?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Admin > Contact center > Utilization',
      'b)Admin > Contact center > ACD Skills',
      'c)Admin > Routing > Emergencies',
      'd)Admin > Routing > Disconnect Interactions',
    ]
};



const question_55=  {
    name: 'answer',
    message: 'Which ACD option helps purecloud to apply business rules in order to process an interaction?',
    correct:"d",
    limit: 10,
    initial: 2,
    choices: [
      'a)Routing method',
      'b)Call flow',
      'c)Evaluation method',
      'd)ACD Processing',
    ]
};



const question_56=  {
    name: 'answer',
    message: 'Which definition matches the after call work option mandatory, time-boxed no early exit?',
    correct:"d",
    limit: 10,
    initial: 2,
    choices: [
      'a)The agent may or may not complete after call work. The system will set them to available after an intercation completes. They are responsible for setting their availability appropiately if perfoming after call work',
      'b)The agent is automatically placed into an after call work status and the system will automatically set them to available when the after call timeout is reached. The agent may set themselves to available if they complete their after call work early',
      'c)The agent is placed in an after call work status and must manually set their status back to available when their after cll work is complete',
      'd)The agent is automatically placed into an after call work status and the system will automatically set them to available when the after call timeout is reached. The agent may not set themselves to available if they complete their after call work early',
    ]
};


const question_57=  {
    name: 'answer',
    message: 'What allows you to assign different levels of access to different users?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Roles',
      'b)Groups',
      'c)Users',
      'd)Administrators',
    ]
};



const question_58=  {
    name: 'answer',
    message: 'What attributes can be assigned to agents to ensure that interactions are routed to the most qualified agent? Choose 2 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Language c)skills',
      'b)Medians',
      'c)Skills',
      'd)Index ratings',
	  'e)Knowledge levels',
    ]
};


const question_59=  {
    name: 'answer',
    message: 'What allows customer interactions to be handled by agents with the rigth skills in the shortest amount of time?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Routing strategies',
      'b)Automatic call distribution',
      'c)Workforce managment',
      'd)Skills based routing',
    ]
};



const question_60=  {
    name: 'answer',
    message: 'Which of the following can be configured on inbound interactions to be used by ACD processing? Choose 2 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Language c)skills',
      'b)Intent of call',
      'c)Skills',
      'd)Agent Availability',
    ]
};



const question_61=  {
    name: 'answer',
    message: 'Which of the following options are used when scheduling a report? Choose 3 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Time period b)Custom date range d)Time zone',
      'c)Recurrences',
	  'e)Start time',
    ]
};



const question_62=  {
    name: 'answer',
    message: 'Which definition matches the analitycs view for interactions?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Used to monitor real-time contact center metrics',
      'b)Used to view real-time metrics, such as status, time in status calls answered, average talk time and average ACW',
      'c)Used to view real-time and historical metrics, such as service level %, abandon %, customers waiting, and active agents',
      'd)Used to view historical data only',
	  'e)Used to view metrics for completed phone calls and chats, such as, the user, remote telephone number, data/time, and duration',
    ]
};



const question_63=  {
    name: 'answer',
    message: 'Select all the roles that are automatically assigned by default to the user who sets up the organization. Choose 2 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Employee d)Admin',
      'b)Master admin',
      'c)Purecloud user',
	  'e)Telephony admin',
    ]
};


const question_64=  {
    name: 'answer',
    message: 'Select the applicable options for purecloud architect. Choose 3 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Play pre-recorded messages and b)Convert text to speech e)Receive and route calls ',
      'b)Convert text to speech',
      'c)Configure queues',
      'd)Configure Skills',
	  'e)Receive and route calls',
    ]
};


const question_65=  {
    name: 'answer',
    message: 'If you have not created any additional templates, you will have several template options when creating a new script. What are the template options? Choose 4 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Blank script b)Default callback script c)Default inbound script d)Default oubound script',
      'd)Sales script template',
	  'e)Collection script template',
    ]
};


const question_66=  {
    name: 'answer',
    message: 'What are callable time sets?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)Callable time sets allows you to define calling times for various time zones. Multiple callable time sets can then be associated with a single campaign',
      'b)Callable time sets allows you to define calling times for various time zones. A callable time set can the be associated with multiple campaigns',
      'c)Callable time sets provide a way to define your own time zones to associate with a campaign',
      'd)Callable time sets are used to define when a campaign start and stops',
    ]
};


const question_67=  {
    name: 'answer',
    message: 'Which definition matches the after call work optional?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)The agent may or may not complete after call work. The system will set them to available after an intercation completes. They are responsible for setting their availability appropiately if perfoming after call work',
      'b)The agent is automatically placed into an after call work status and the system will automatically set them to available when the after call timeout is reached. The agent may set themselves to available if they complete their after call work early',
      'c)The agent is placed in an after call work status and must manually set their status back to available when their after cll work is complete',
      'd)The agent is automatically placed into an after call work status and the system will automatically set them to available when the after call timeout is reached. The agent may not set themselves to available if they complete their after call work early',
    ]
};



const question_68=  {
    name: 'answer',
    message: 'Which definition matches the ACD evaluation method Disgregard skills, next agent?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Looks for the first available agent and ignores any skill requirements',
      'b)Matches the intercation to the first available agent who has all of the requested skills',
      'c)Evaluates the first 100 agents to find the agent with the highest average proficiency rating. The average is calculated using the agentes proficiency rating for each of the requested skills',
    ]
};


const question_69=  {
    name: 'answer',
    message: 'How many levels of licensing of genesys cloud?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)3',
      'b)4',
      'c)2',
      'd)5',
    ]
};



const question_70=  {
    name: 'answer',
    message: 'You can play shipper audio only if the agent is configured for auto-answer',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)True',
      'b)False',
    ]
};



const question_71=  {
    name: 'answer',
    message: 'Wich of the following options a the best way to monitor the devolution from the forecast versus the real time?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)real time adherence',
      'b)historial adherence',
      'c)intradia monitoring',
      'd)view agent schedule',
    ]
};



const question_72=  {
    name: 'answer',
    message: 'wich Genesys Cloud following helps to ensure that enough agents are in the right place at the right time?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Routing',
      'b)Queue management',
      'c)Workforce management',
      'd)Reporting and analitycs',
    ]
};


const question_73=  {
    name: 'answer',
    message: 'Wich funcionalities are available in Genesys cloud WFM, Choose 2 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)short time forecast d)forecast simulator',
      'b)scheduling',
      'c)long time forecast',
      'd)forecast simulator',
    ]
};



const question_74=  {
    name: 'answer',
    message: 'Cuando el metodo Bullseye Routing es usado y no coincide con el primero, las siguientes busquedas ignoran los requerimientos de skill',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)true',
      'b)false',
    ]
};



const question_75=  {
    name: 'answer',
    message: 'What options are required to configure a queue. Select 2 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Wap-Up Codes b)ACD Skills',
      'c)Utilization',
      'd)Alerting timeout',
	  'e)inbound flows',
    ]
};



const question_76=  {
    name: 'answer',
    message: 'Las licencias usadas por los usuarios esta determinada por los roles y permisos que le asignan a los usuarios?',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)true',
      'b)false',
    ]
};




const question_77=  {
    name: 'answer',
    message: 'Why is a Division in an Organization important?',
    correct:"d",
    limit: 10,
    initial: 2,
    choices: [
      'a)La division es usada para dividir las interacciones entre colas',
      'b)La division ayuda a organizar por roles',
      'c)Las colas se pueden asignar por division',
      'd)La division permite agrupar y segmentar por negocios dentro de la organización',
    ]
};




const question_78=  {
    name: 'answer',
    message: 'Select Promps categories in Architect. Select 2 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)User c)Data',
      'b)Menu',
      'c)Data',
      'd)Systems',
    ]
};



const question_79=  {
    name: 'answer',
    message: 'Wich of the following components can be added to scripts?. Choose 4 answers',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Visual Basic Control d)Checkbox e)Web page f)Image ',
      'b)Text',
      'c)Call flows',
      'd)Checkbox',
	  'e)Web page',
	    'f)Image',
    ]
};



const question_80=  {
    name: 'answer',
    message: 'You cannot add variables to a script',
    correct:"b",
    limit: 10,
    initial: 2,
    choices: [
      'a)True',
      'b)False',
	  'e)',
    ]
};



const question_81=  {
    name: 'answer',
    message: 'Which dialing mode start multiple contacts once an agent become available?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Power',
      'b)Predicitive',
      'c)Progresive',
      'd)Agentless',
    ]
};



const question_82=  {
    name: 'answer',
    message: 'For outbound dialing, where do you configure the dialing mode?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)In the Contact List object',
      'b)In the queue object',
      'c)In the campaign object',
    ]
};




const question_83=  {
    name: 'answer',
    message: 'Where are Genesys Cloud call recordings stored by default?',
    correct:"d",
    limit: 10,
    initial: 2,
    choices: [
      'a)Recording Manager',
      'b)Cloud',
      'c)Web Service',
      'd)AWS Cloud',
    ]
};



const question_84=  {
    name: 'answer',
    message: 'Wich of the following is not a quality management feature?',
    correct:"c",
    limit: 10,
    initial: 2,
    choices: [
      'a)Evaluations forms',
      'b)Policies',
      'c)Scheduling',
      'd)Interaction Recording',
    ]
};



const question_85=  {
    name: 'answer',
    message: 'What is a critical question in a evaluation forms?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Critical questions are used to priorize questions that are critical to the success of an interaction. A separate critical score is calculated for critical questions',
      'c)?',
      'd)?',
    ]
};



const question_86=  {
    name: 'answer',
    message: 'By default. Line Recording is disabled',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)True',
      'b)False',
    ]
};



const question_87=  {
    name: 'answer',
    message: 'Un gerente de una empresa maneja la planificación de sus horario, break, capacitaciones en hoja de excel. Que componente de Genesys Cloud llegó para remplazar el uso de excel?',
    correct:"a",
    limit: 10,
    initial: 2,
    choices: [
      'a)Genesys Cloud Workforce Management',
      'b)Genesys Cloud API',
      'c)Genesys Cloud Architect',
      'd)Genesys Cloud Reporting and analitycs',
    ]
};




const questions = [
    question_1,
    question_2,
    question_3,
    question_4,
    question_5,
    question_6,
    question_7,
    question_8,
    question_9,
    question_10,
    question_11,
    question_12,  
    question_13,
    question_14,
    question_15,
    question_16,
    question_17,
    question_18,
    question_19,
    question_20,
    question_21,
    question_22,
    question_23,
    question_24,
    question_25,
    question_26,
    question_27,
    question_28,
    question_29,
    question_27,
    question_28,
    question_29,
    question_30,
    question_31,
    question_32,
    question_33,
    question_34,
    question_35,
    question_36,
    question_37,
    question_38,
    question_39,
    question_40,
    question_41,
    question_42,
    question_43,
    question_44,
    question_45,
    question_46,
    question_47,
    question_48,
    question_49,
    question_50,
    question_51,
    question_52,
    question_53,
    question_54,
    question_55,
    question_56,
    question_57,
    question_58,
    question_59,
    question_60,
    question_61,
    question_62,
    question_63,
    question_64,
    question_65,
    question_66,
    question_67,
    question_68,
    question_69,
    question_70,
    question_71,
    question_72,
    question_73,
    question_74,
    question_75,
    question_76,
    question_77,
    question_78,
    question_79,
    question_80,
    question_81,
    question_82,
    question_83,
    question_84,
    question_85,
    question_86,
    question_87

]

module.exports = questions;
